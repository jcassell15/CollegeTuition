package com.zybooks.concerttickets;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Button;
import android.view.View;
import android.content.Intent;

import java.text.DecimalFormat;

public class PartTime extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_part_time);
        final EditText numcredits = ((EditText)findViewById(R.id.crhours));
        final TextView result = ((TextView)findViewById(R.id.txtResult));

        Button newButton1 = (Button) findViewById(R.id.button2);
        newButton1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                //Intent intent = new Intent(DayStudent.this, ThirdActivity.class);
                //startActivity(intent);
                int numberofCredits = Integer.parseInt (numcredits.getText().toString());
                // Numberofcredits is ready to use in math

                int totalCost = numberofCredits * 816;
                //DecimalFormat currency = new DecimalFormat("$###, ###.##");
                result.setText("Cost is " +  (totalCost));
            }
        });

        Button homebutton = (Button) findViewById(R.id.backbutton);
        homebutton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent = new Intent(PartTime.this, MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

        // declare button for the java program
        // set up on click listener and action event for button click
        //button click ends here

    }
}

