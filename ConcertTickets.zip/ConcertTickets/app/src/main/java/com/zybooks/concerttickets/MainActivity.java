package com.zybooks.concerttickets;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DecimalFormat;


public class MainActivity extends AppCompatActivity {
    //private Button button;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button button1 = (Button) findViewById(R.id.btnDay);
        Button button2 = (Button) findViewById(R.id.btnPartTime);
        Button button3 = (Button) findViewById(R.id.btnSummer);


        //final EditText tickets = (EditText)findViewById(R.id.txtTickets);
        //Button cost = (Button)findViewById(R.id.btnCost);
        button1.setOnClickListener(new View.OnClickListener() {
                //final TextView result = ((TextView)findViewById(R.id.txtResult));
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(MainActivity.this,DayStudent.class);
                    startActivity(intent);
                    finish();

                }
        });
//
        button2.setOnClickListener(new View.OnClickListener() {
            //final TextView result = ((TextView)findViewById(R.id.txtResult));
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,PartTime.class);
                startActivity(intent);
                finish();

            }
        });
        //
        button3.setOnClickListener(new View.OnClickListener() {
            //final TextView result = ((TextView)findViewById(R.id.txtResult));
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this,SummerStudent.class);
                startActivity(intent);
                finish();

            }
        });

        }
    }


